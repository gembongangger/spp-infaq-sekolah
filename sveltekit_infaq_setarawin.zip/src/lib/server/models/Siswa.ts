/**
 * Siswa Model
 */
import db from '$lib/server/db';
import { v4 as uuidv4 } from 'uuid';

export interface Siswa {
	id: string;
	nomor_akun: string;
	nama: string;
	kelas: string;
	created_at: string;
	updated_at: string | null;
}

export interface SiswaDTO {
	id: string;
	nomorAkun: string;
	nama: string;
	kelas: string;
	createdAt: string;
	updatedAt: string | null;
}

export const Siswa = {
	/** Convert raw DB row to DTO */
	toDTO(siswa: Siswa): SiswaDTO {
		return {
			id: siswa.id,
			nomorAkun: siswa.nomor_akun,
			nama: siswa.nama,
			kelas: siswa.kelas,
			createdAt: siswa.created_at,
			updatedAt: siswa.updated_at,
		};
	},

	/** Get all siswa */
	getAll(): Siswa[] {
		const stmt = db.prepare('SELECT * FROM siswa ORDER BY created_at DESC');
		return stmt.all() as Siswa[];
	},

	/** Get siswa by ID */
	findById(id: string): Siswa | null {
		const stmt = db.prepare('SELECT * FROM siswa WHERE id = ?');
		return stmt.get(id) as Siswa | null;
	},

	/** Get siswa by nomor_akun */
	findByNomorAkun(nomorAkun: string): Siswa | null {
		const stmt = db.prepare('SELECT * FROM siswa WHERE nomor_akun = ?');
		return stmt.get(nomorAkun) as Siswa | null;
	},

	/** Create new siswa */
	create(data: { nomorAkun: string; nama: string; kelas: string }): Siswa {
		const id = uuidv4();
		const now = new Date().toISOString();

		const stmt = db.prepare(`
			INSERT INTO siswa (id, nomor_akun, nama, kelas, created_at, updated_at)
			VALUES (?, ?, ?, ?, ?, ?)
		`);

		stmt.run(id, data.nomorAkun, data.nama, data.kelas, now, now);

		return this.findById(id)!;
	},

	/** Update siswa */
	update(id: string, data: Partial<{ nomorAkun: string; nama: string; kelas: string }>): Siswa | null {
		const now = new Date().toISOString();
		const updates: string[] = [];
		const values: (string | null)[] = [];

		if (data.nomorAkun !== undefined) {
			updates.push('nomor_akun = ?');
			values.push(data.nomorAkun);
		}
		if (data.nama !== undefined) {
			updates.push('nama = ?');
			values.push(data.nama);
		}
		if (data.kelas !== undefined) {
			updates.push('kelas = ?');
			values.push(data.kelas);
		}

		if (updates.length === 0) {
			return this.findById(id);
		}

		updates.push('updated_at = ?');
		values.push(now);
		values.push(id);

		const stmt = db.prepare(`
			UPDATE siswa 
			SET ${updates.join(', ')}
			WHERE id = ?
		`);

		stmt.run(...values);

		return this.findById(id);
	},

	/** Delete siswa */
	delete(id: string): boolean {
		const stmt = db.prepare('DELETE FROM siswa WHERE id = ?');
		const result = stmt.run(id);
		return result.changes > 0;
	},

	/** Search siswa with pagination */
	search(options: {
		query?: string;
		limit?: number;
		offset?: number;
	}): { students: Siswa[]; total: number; hasMore: boolean } {
		const { query = '', limit = 20, offset = 0 } = options;

		// Count total matching records
		let countStmt;
		let countParams: (string | number)[] = [];
		
		if (query.trim()) {
			const searchPattern = `%${query.trim()}%`;
			countStmt = db.prepare(`
				SELECT COUNT(*) as count
				FROM siswa
				WHERE nama LIKE ? OR nomor_akun LIKE ? OR kelas LIKE ?
			`);
			countParams = [searchPattern, searchPattern, searchPattern];
		} else {
			countStmt = db.prepare('SELECT COUNT(*) as count FROM siswa');
		}
		
		const totalResult = countStmt.get(...countParams) as { count: number };
		const total = totalResult.count;

		// Get paginated results
		let searchStmt;
		let searchParams: (string | number)[] = [];
		
		if (query.trim()) {
			const searchPattern = `%${query.trim()}%`;
			searchStmt = db.prepare(`
				SELECT * FROM siswa
				WHERE nama LIKE ? OR nomor_akun LIKE ? OR kelas LIKE ?
				ORDER BY nama ASC
				LIMIT ? OFFSET ?
			`);
			searchParams = [searchPattern, searchPattern, searchPattern, limit, offset];
		} else {
			searchStmt = db.prepare(`
				SELECT * FROM siswa
				ORDER BY nama ASC
				LIMIT ? OFFSET ?
			`);
			searchParams = [limit, offset];
		}

		const students = searchStmt.all(...searchParams) as Siswa[];
		const hasMore = offset + students.length < total;

		return {
			students: students.map(s => s),
			total,
			hasMore
		};
	},

	/** Batch create for Excel import */
	batchCreate(dataArray: { nomorAkun: string; nama: string; kelas: string; rowNumber?: number }[]): {
		success: number;
		duplicate: number;
		failed: number;
		errors: string[];
	} {
		const result = {
			success: 0,
			duplicate: 0,
			failed: 0,
			errors: [] as string[],
		};

		const insertStmt = db.prepare(`
			INSERT INTO siswa (id, nomor_akun, nama, kelas, created_at, updated_at)
			VALUES (?, ?, ?, ?, ?, ?)
		`);

		const checkStmt = db.prepare('SELECT id FROM siswa WHERE nomor_akun = ?');

		const insertMany = db.transaction((students: typeof dataArray) => {
			for (let i = 0; i < students.length; i++) {
				const data = students[i];
				const rowNumber = data.rowNumber ?? i + 2; // Excel row number (header is row 1)

				try {
					// Check duplicate
					const existing = checkStmt.get(data.nomorAkun);
					if (existing) {
						result.duplicate++;
						result.errors.push(`Baris ${rowNumber}: Nomor akun "${data.nomorAkun}" sudah ada`);
						continue;
					}

					const id = uuidv4();
					const now = new Date().toISOString();
					insertStmt.run(id, data.nomorAkun, data.nama, data.kelas, now, now);
					result.success++;
				} catch (error) {
					result.failed++;
					result.errors.push(`Baris ${rowNumber}: ${(error as Error).message}`);
				}
			}
		});

		insertMany(dataArray);

		return result;
	},
};
